# Unified Pixel 7 / 8 / 9 Sultan + fgetpriority workflow

Workflow: `.github/workflows/build-pixel7-8-9-fgetpriority.yml`

## Targets

- `gs201`: Pixel 7 family / Tensor G2
- `zuma`: Pixel 8 family / Tensor G3
- `zumapro`: Pixel 9 family / Tensor G4
- `all`: builds the three platform targets in parallel

The workflow checks whether the selected branch/tag contains the corresponding defconfig. If the upstream fork uses different config names, the build fails early and lists matching configs instead of silently producing a wrong-target kernel.

## fgetpriority

The workflow checks out `aerath-stuff/fgetpriority` branch `lkm`, builds its kernel module against the configured kernel output, and places the `.ko` and relevant helper/install files in the downloadable artifact. The build is intentionally fail-fast if no module is produced.

## Important

This workflow produces build-artifact ZIPs, not device-ready AnyKernel3 flash ZIPs. The unified source branch and each device's boot/vendor_boot/DTB packaging requirements must be verified before flashing. GitHub Actions compilation is not a substitute for device testing. Do not flash artifacts on a device unless the kernel branch, boot image format, DTB/DTBO handling, and module signing/KMI requirements match that device and ROM.
